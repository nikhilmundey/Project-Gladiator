package com.lti.controller;

import java.time.LocalDate;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.lti.entity.StudentAcademic;
import com.lti.entity.StudentBankDetails;
import com.lti.entity.StudentBasicDetails;
import com.lti.entity.StudentDocument;
import com.lti.entity.StudentReg;
import com.lti.service.StudentService;

@Controller
@SessionAttributes("student")
public class StudentController {
	
	@Autowired
	private StudentService studentService;

	@RequestMapping(path = "studentregister.lti", method = RequestMethod.POST)
	public String register(StudentReg studentReg,@RequestParam("studentDOB") String studentdob )
	{
		
		LocalDate studentDOB = LocalDate.parse( studentdob);     
		studentReg.setStudentDOB(studentDOB);          
		studentService.register(studentReg);
		return "home.jsp";
	}

	
	@RequestMapping(path="ss.lti",method=RequestMethod.POST)
	public String studentLogin(
			@RequestParam("studentEmail") String studentEmail, 
			@RequestParam("studentPassword") String studentPassword,
			ModelMap model){


		StudentReg studentReg=studentService.checkLogin(studentEmail, studentPassword);
		if(studentReg != null) {
			model.put("student", studentReg);
			return "navdetails.jsp";
		}
		else {
			 model.put("message", "Invalid username/password");
			 return "studentlogin.jsp";
		 }
	}
	
	
	@RequestMapping(path = "studentbasic.lti", method = RequestMethod.POST)
	public String addBasic(StudentBasicDetails studBasic, ModelMap model)
	{    
		StudentReg s=(StudentReg) model.get("student");
		studBasic.setStudentReg(s);
		
		studentService.addStudentBasic(studBasic);
		return "studAcademic.jsp";
	}
	
	@RequestMapping(path = "studentacademic.lti", method = RequestMethod.POST)
	public String addAcademic(StudentAcademic studAcademic,@RequestParam("classStartDate") String classDate, ModelMap model)
	{
		StudentReg s=(StudentReg) model.get("student");
		studAcademic.setStudentReg(s);
		LocalDate classStartDate = LocalDate.parse(classDate);     
		studAcademic.setClassStartDate(classStartDate);          
		studentService.addAcademic(studAcademic);
		return "bank.jsp";
	}
	
	
	@RequestMapping(path = "studentbank.lti", method = RequestMethod.POST)
	public String addBank(StudentBankDetails studBank, ModelMap model)
	{   
		StudentReg s=(StudentReg) model.get("student");
		studBank.setStudentReg(s);
		studentService.addBank(studBank);
		return "stdDoc.jsp";
	}
	
	@RequestMapping(path = "studentdoc.lti", method = RequestMethod.POST)
	public String addDoc(StudentDocument studDoc, ModelMap model)
	{        
		StudentReg s=(StudentReg) model.get("student");
		studDoc.setStudentReg(s);
		studentService.addDoc(studDoc);
		return "home.jsp"; // It should go to Apply for schemes page. for now it is Home
	}
}
