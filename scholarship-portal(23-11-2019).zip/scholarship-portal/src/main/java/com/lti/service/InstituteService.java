package com.lti.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.entity.Institute;
import com.lti.entity.StudentReg;
import com.lti.repository.GenericDao;
import com.lti.repository.InstituteDao;

@Service
public class InstituteService {

	@Autowired
	private GenericDao gdao;
	
	@Autowired
	private InstituteDao instituteDao;
	
	public void register(Institute institute){
		            
		gdao.add(institute);

	}

	public List <Institute> getinsdetail(){
		
		List<Institute> serobj = instituteDao.getinsdetail();
			return serobj;
	}


	public Institute checkLogin(int instituteCode, String password) {
		
		Institute institute=instituteDao.readLogin(instituteCode, password);
		return institute;

	}
	
	
	public List <StudentReg> viewApplications(int instCode)
	{
		List<StudentReg> slist = instituteDao.viewApplications(instCode);
		return slist;
	}
}
