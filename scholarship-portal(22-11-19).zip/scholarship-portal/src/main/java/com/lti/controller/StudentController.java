package com.lti.controller;

import java.time.LocalDate;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.lti.entity.StudentAcademic;
import com.lti.entity.StudentBankDetails;
import com.lti.entity.StudentBasicDetails;
import com.lti.entity.StudentDocument;
import com.lti.entity.StudentReg;
import com.lti.service.StudentService;

@Controller
@SessionAttributes("student")
public class StudentController {
	
	@Autowired
	private StudentService studentService;

	@RequestMapping(path = "studentregister.lti", method = RequestMethod.POST)
	public String register(StudentReg studentReg,@RequestParam("sdob") String bdt )
	{
		
		LocalDate studentDOB = LocalDate.parse( bdt);     
		studentReg.setStudentDOB(studentDOB);          
		studentService.register(studentReg);
		return "home.jsp";
	}

//	@Autowired
//	private HttpSession httpsession; 
	@RequestMapping(path="ss.lti",method=RequestMethod.POST)
	public String studentLogin(@RequestParam("studentId") String studentId, @RequestParam("studentPassword") String studentPassword, StudentReg studentReg, HttpSession httpSession){
		//httpSession.setAttribute("studId", studentReg.getStudentId());
		boolean i=studentService.checkLogin(Integer.parseInt(studentId), studentPassword);
		//ModelAndView mv=new ModelAndView("home.jsp");

		if(i){
			
			System.out.println("Login Success");
			return "navdetails.jsp";
		}
		else{
			System.out.println("Login Failed");
			return null;

		}
	}
	
	@RequestMapping(path = "studentbasic.lti", method = RequestMethod.POST)
	public String addBasic(StudentBasicDetails studBasic)
	{        
		studentService.addStudentBasic(studBasic);
		return "studAcademic.jsp";
	}
	
	@RequestMapping(path = "studentacademic.lti", method = RequestMethod.POST)
	public String addAcademic(StudentAcademic studAcademic,@RequestParam("cdob") String csd )
	{
		
		LocalDate classStartDate = LocalDate.parse(csd);     
		studAcademic.setClassStartDate(classStartDate);          
		studentService.addAcademic(studAcademic);
		return "bank.jsp";
	}
	
	
	@RequestMapping(path = "studentbank.lti", method = RequestMethod.POST)
	public String addBank(StudentBankDetails studBank)
	{        
		studentService.addBank(studBank);
		return "stdDoc.jsp";
	}
	
	@RequestMapping(path = "studentdoc.lti", method = RequestMethod.POST)
	public String addDoc(StudentDocument studDoc)
	{        
		studentService.addDoc(studDoc);
		return "home.jsp"; // It should go to Apply for schemes page. for now it is Home
	}
}
