package com.lti.repository;

import com.lti.entity.Institute;

public interface InstituteInterface {

	public void add(Institute institute);

}
