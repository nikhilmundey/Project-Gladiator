package com.lti.entity;

public class StudentAcademic {

}
